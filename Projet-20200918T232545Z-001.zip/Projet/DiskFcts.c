#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#define TAILLE_MAX 1000

int LectureData(double *poubelle, double *vs, double *rpg, double *Mp, int *Nt, double *dt, double *ep, double *rph, double *Tp, double *MS)
{
    FILE* fichier = NULL;
    fichier = fopen("donneesinitiales.txt", "r");
    char chaine[TAILLE_MAX] = "";
    fgets(chaine, TAILLE_MAX, fichier);
    sscanf(chaine, "%lf", poubelle);
    fgets(chaine, TAILLE_MAX, fichier);
    sscanf(chaine, "%lf", vs);
    fgets(chaine, TAILLE_MAX, fichier);
    sscanf(chaine, "%lf", rpg);
    fgets(chaine, TAILLE_MAX, fichier);
    sscanf(chaine, "%lf", Mp);
    fgets(chaine, TAILLE_MAX, fichier);
    sscanf(chaine, "%d", Nt);
    fgets(chaine, TAILLE_MAX, fichier);
    sscanf(chaine, "%lf", dt);
    fgets(chaine, TAILLE_MAX, fichier);
    sscanf(chaine, "%lf", ep);
    fgets(chaine, TAILLE_MAX, fichier);
    sscanf(chaine, "%lf", rph);
    fgets(chaine, TAILLE_MAX, fichier);
    sscanf(chaine, "%lf", Tp);
    fgets(chaine, TAILLE_MAX, fichier);
    sscanf(chaine, "%lf", MS);
    fclose(fichier);
    return 1;
}

float Conversion(double *rpg, double *Mp, double *rph, double *Tp, double *MS)
{
    *rpg = *rpg * 1000; //Conversion km en m
    *Mp = *Mp*pow(10, 24); //Conversion 10^24kg en kg, pour la Terre
    *rph = *rph * pow(10, 9); //Conversion 10^6km en m, pour le Soleil
    *Tp = *Tp *24*3600; //Conversion de jours en secondes
    *MS = *MS *pow(10, 30); //Conversion 10^30kg, pour le Soleil
}

int EcritureTrajSatellite(double *Xs, double *Ys, int *Nt)
{
    FILE* fichier = NULL;
    fichier = fopen("TrajectoireSatellite.txt", "w");
    for (int i=0;i<*Nt;i++)
    {
        fprintf(fichier, "%lf\t%lf\n", Xs[i], Ys[i]);
    }
    fclose(fichier);
}

//int EcritureTrajPlanete(double *Xp, double *Yp, int *Nt)
//{
//    FILE* fichier = NULL;
//    fichier = fopen("TrajectoirePlanete.txt", "w");
//    for (int i=0;i<*Nt;i++)
//    {
//        fprintf(fichier, "%lf\t%lf\n", Xp[i], Yp[i]);
//    }
//    fclose(fichier);
//}