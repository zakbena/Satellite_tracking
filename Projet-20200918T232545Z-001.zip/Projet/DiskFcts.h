int LectureData(double *poubelle, double *vs, double *rpg, double *Mp, int *Nt, double *dt, double *ep, double *rph, double *Tp, double *MS);
float Conversion(double *rpg, double *Mp, double *rph, double *Tp, double *MS);
int EcritureTrajSatellite(double *Xs, double *Ys, int *Nt);
//int EcritureTrajPlanete(double *Xp, double *Yp, int *Nt);