#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#define TAILLE_MAX 1000

int LectureData(float *poubelle, float *vs, float *rpg, float *Mp, int *Nt, float *dt, float *ep, float *rph, float *Tp, float *MS)
{
    FILE* fichier = NULL;
    fichier = fopen("donneesinitiales.txt", "r");
    char chaine[TAILLE_MAX] = "";
    fgets(chaine, TAILLE_MAX, fichier);
    sscanf(chaine, "%f", poubelle);
    fgets(chaine, TAILLE_MAX, fichier);
    sscanf(chaine, "%f", vs);
    fgets(chaine, TAILLE_MAX, fichier);
    sscanf(chaine, "%f", rpg);
    fgets(chaine, TAILLE_MAX, fichier);
    sscanf(chaine, "%f", Mp);
    fgets(chaine, TAILLE_MAX, fichier);
    sscanf(chaine, "%d", Nt);
    fgets(chaine, TAILLE_MAX, fichier);
    sscanf(chaine, "%f", dt);
    fgets(chaine, TAILLE_MAX, fichier);
    sscanf(chaine, "%f", ep);
    fgets(chaine, TAILLE_MAX, fichier);
    sscanf(chaine, "%f", rph);
    fgets(chaine, TAILLE_MAX, fichier);
    sscanf(chaine, "%f", Tp);
    fgets(chaine, TAILLE_MAX, fichier);
    sscanf(chaine, "%f", MS);
    fclose(fichier);
    return 1;
}

float Conversion(float *rpg, float *Mp, float *rph, float *Tp, float *MS)
{
    *rpg = *rpg * 1000; //Conversion km en m
    *Mp = *Mp*pow(10, 24); //Conversion 10^24kg en kg, pour la Terre
    *rph = *rph * pow(10, 9); //Conversion 10^6km en m, pour le Soleil
    *Tp = *Tp *24*3600; //Conversion de jours en secondes
    *MS = *MS*pow(10, 30); //Conversion 10^30kg, pour le Soleil
}

int EcritureTrajSatellite(float *Xs, float *Ys, int *Nt)
{
    FILE* fichier = NULL;
    fichier = fopen("TrajectoireSatellite.txt", "w");
    for (int i=0;i<*Nt;i++)
    {
        fprintf(fichier, "%f\t%f\n", Xs[i], Ys[i]);
    }
    fclose(fichier);
}

int EcritureTrajPlanete(float *Xp, float *Yp, int *Nt)
{
    FILE* fichier = NULL;
    fichier = fopen("TrajectoirePlanete.txt", "w");
    for (int i=0;i<*Nt;i++)
    {
        fprintf(fichier, "%f\t%f\n", Xp[i], Yp[i]);
    }
    fclose(fichier);
}