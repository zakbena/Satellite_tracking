int LectureData(float *poubelle, float *vs, float *rpg, float *Mp, int *Nt, float *dt, float *ep, float *rph, float *Tp, float *MS);
float Conversion(float *rpg, float *Mp, float *rph, float *Tp, float *MS);
int EcritureTrajSatellite(float *Xs, float *Ys, int *Nt);
int EcritureTrajPlanete(float *Xp, float *Yp, int *Nt);