#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#define PI 3.14159

//Calcul de la trajectoire de la planète
float TrajectoirePlanete(float *ep, float *rph, float *Tp, float *MS, float *vp, float *Ap, float *dt, float *Ep, float *thetaP, float *rp, float *Xp, float *Yp, int *Nt)
{
  double *ratio=NULL;
  ratio=malloc(*Nt* sizeof(float));
  float G = 6.6742*pow(10, -11);
  *vp = sqrt((*MS*G*(1+*ep))/ *rph);
  for (int i=0;i<*Nt;i++)
  {
    Ap[i] = (i* *dt * 2 * PI)/(*Tp);
    //Trouver E, d'après Appendix D11 du manuel
    float error = pow(10, -8);
    if (Ap[i] < PI)
    {
      Ep[i] = Ap[i] + (*ep/2);
    }
    else
    {
      Ep[i] = Ap[i] - (*ep/2);
    }
    while (fabs(ratio[i]) > error)
    {
      ratio[i] = (Ep[i] - *ep*sin(Ep[i]) - Ap[i])/(1 - *ep*cos(Ep[i]));
      Ep[i] = Ep[i] - ratio[i];
    }
    //E trouvé
    thetaP[i] = 2 * atan(tan(Ep[i] / 2) / sqrt((1 - *ep) / (1 + *ep)));
    rp[i] = (pow(*rph*(*vp), 2) / (*MS*G)) / (1 + *ep * cos(thetaP[i]));
    Xp[i] = rp[i] * sin(thetaP[i]);
    Yp[i] = rp[i] * cos(thetaP[i]);
  }
}

//Calcul de l'excentricite
float ParaGravStd(float *rpg, float *vs, float *mu, float *Mp)
{
  float G = 6.6742*pow(10, -11);
  *mu = *Mp*G;
}

float SpecAngMom(float *rpg, float *vs, float *h)
{
  *h = *rpg*(*vs);
}

float excentricite(float *h, float *mu, float *e, float *rpg)
{
  *e = (pow(*h, 2)/(*rpg*(*mu))) - 1;
}

//Si e<1
float elliptique(float *T, float *mu, float *h, float *e, float *dt, float *A, float *E, float *thetaB, float *r, float *Xp, float *Yp, float *Xs, float *Ys, int *Nt)
{
  double *ratio=NULL;
  ratio=malloc(*Nt* sizeof(float));
  for (int i=0;i<*Nt;i++)
  {
    *T = ((2*PI)/pow(*mu, 2))*pow(*h/(sqrt(1 - pow(*e, 2))), 3);
    A[i] = (i* *dt * 2 * PI)/(*T);
    //Trouver E, d'après Appendix D11 du manuel
    float error = pow(10, -8);
    if (A[i] < PI)
    {
      E[i] = A[i] + (*e/2);
    }
    else
    {
      E[i] = A[i] - (*e/2);
    }
    while (fabs(ratio[i]) > error)
    {
      ratio[i] = (E[i] - *e*sin(E[i]) - A[i])/(1 - *e*cos(E[i]));
      E[i] = E[i] - ratio[i];
    }
    //E trouvé
    thetaB[i] = 2 * atan(tan(E[i] / 2) / sqrt((1 - *e) / (1 + *e)));
    r[i] = (pow(*h, 2) / *mu) / (1 + *e * cos(thetaB[i]));
    Xs[i] = Xp[i] + r[i] * sin(thetaB[i]);
    Ys[i] = Yp[i] + r[i] * cos(thetaB[i]);
  }
}

//Si e=1
float parabolique(float *A, float *mu, float *dt, float *h, float *thetaB, float *r, float *Ys, float *Xs, float *Yp, float *Xp, int *Nt)
{
  for (int i=0;i<*Nt;i++)
  {
    A[i] = (pow(*mu, 2)*i* *dt)/pow(*h, 3);
    thetaB[i] = 2*atan(cbrt(3*A[i]+sqrt(pow(3*A[i], 2)+1))-(1/(cbrt(3*A[i]+sqrt(pow(3*A[i], 2)+1)))));
    r[i] = (pow(*h, 2)/ *mu)*(1/(1+cos(thetaB[i])));
    Xs[i] = Xp[i] + r[i]*sin(thetaB[i]);
    Ys[i] = Yp[i] + r[i]*cos(thetaB[i]);
  }
}


//Si e>1
float hyperbolique(float *A, float *dt, float *mu, float *e, float *h, float *thetaB, float *F, float *r, 
float *Ys, float *Xs, float *Yp, float *Xp, int *Nt,float *P)
{
  double *ratio=NULL;
  ratio=malloc((*Nt)* sizeof(float));
  for(int i=0;i<*Nt;i++)
  {
  	A[i] = *dt*i*((pow(*mu, 2)*sqrt(pow(pow(*e, 2)-1, 3)))/pow(*h, 3));
    //Trouver F, d'après Appendix D12 du manuel 
    float error = pow(10, -8);
   for(int i=0;i<*Nt;i++)		
	{ F[i] = A[i];
	   while (fabs(ratio[i])>error)
    {
	//  F[i] = A[i];
      ratio[i] =  (*e * sinh(F[i]) - F[i] - A[i])/(*e * cosh(F[i]) - 1);
      P[i] = F[i] - ratio[i]; 
    }  
 	}
    //F trouvé
    thetaB[i] =2*atan(sqrt((*e+1)/(*e-1))*tanh(P[i]/2));
    r[i] = (pow(*h, 2)/ *mu)*(1/(1+*e*cos(thetaB[i])));
    Xs[i] = Xp[i] + r[i]*sin(thetaB[i]);
    Ys[i] = Yp[i] + r[i]*cos(thetaB[i]); 
  } 
}


