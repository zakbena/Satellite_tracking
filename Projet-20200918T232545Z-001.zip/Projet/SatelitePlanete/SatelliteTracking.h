float TrajectoirePlanete(float *ep, float *rph, float *Tp, float *MS, float *vp, float *Ap, float *dt, float *Ep, float *thetaP, float *rp, float *Xp, float *Yp, int *Nt);
float ParaGravStd(float *rpg, float *vs, float *mu, float *Mp);
float SpecAngMom(float *rpg, float *vs, float *h);
float excentricite(float *h, float *mu, float *e, float *rpg);
float elliptique(float *T, float *mu, float *h, float *e, float *dt, float *A, float *E, float *thetaB, float *r, float *Xp, float *Yp, float *Xs, float *Ys, int *Nt);
float parabolique(float *A, float *mu, float *dt, float *h, float *thetaB, float *r, float *Ys, float *Xs, float *Yp, float *Xp, int *Nt);
float hyperbolique(float *A, float *dt, float *mu, float *e, float *h, float *thetaB, float *F, float *r, float *Ys, float *Xs, float *Yp, float *Xp, int *Nt,float *P);
