#include <stdio.h>

int AffichageIni()
{
    printf("SATELLITE TRACKING\n");
    printf("Last modifications : 07/11/19\n");
    return 1;
}

int FinProg()
{
    printf("A bientot\n");
}

int AffichageData(float *vs, float *rpg, float *Mp, int *Nt, float *dt, float *ep, float *rph, float *Tp, float *MS)
{
    printf("vp = %.2f m/s\n", *vs);
    printf("rp = %.2f km\n", *rpg);
    printf("Mp = %.2f x10^24kg\n", *Mp);
    printf("Nt = %d\n", *Nt);
    printf("dt = %.2f secondes\n", *dt);
    printf("ep = %f\n", *ep);
    printf("rph = %.2f x10^9km\n", *rph);
    printf("Tp = %.2f jours\n", *Tp);
    printf("MS = %.2f x10^30kg\n", *MS);
}

/*int AfficheTrajectoireSatellite(float *Xs, float *Ys, int *Nt, float *t)
{
    int i;

    for (i=0;i<*Nt;i++)
    {
        printf("Xs = %.2f\tYs = %.2f\n", Xs[i], Ys[i]);
    }
}*/