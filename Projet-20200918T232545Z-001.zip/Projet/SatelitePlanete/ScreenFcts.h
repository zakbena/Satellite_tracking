int AffichageIni();
int FinProg();
int AffichageData(float *vs, float *rpg, float *Mp, int *Nt, float *dt, float *ep, float *rph, float *Tp, float *MS);
//int AfficheTrajectoireSatellite(float *Xs, float *Ys, int *Nt, float *t);