#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include "SatelliteTracking.h"
#include "DiskFcts.h"
#include "ScreenFcts.h"

int main(int argc, char *argv[])
{
    //Definition des variables
    float vs = 0;
    float vp = 0;
    float poubelle = 0;
    float rpg = 0;
    float rph = 0;
    float Mp = 0;
    float MS = 0;
    float dt = 0;
    float T = 0;
    float Tp = 0;
    float mu = 0;
    float h = 0;
    float e = 0;
    float ep = 0;
    int Nt = 0;

    //Appel de la fonction gérant l'affichage de bienvenue
    AffichageIni();

    //Appel de la fonction lisant le fichier de donnees
    //Lecture du fichier de donnees (par defaut "donneesinitiales.txt")
    LectureData(&poubelle, &vs, &rpg, &Mp, &Nt, &dt, &ep, &rph, &Tp, &MS);

    //Affichage des differentes informations
    AffichageData(&vs, &rpg, &Mp, &Nt, &dt, &ep, &rph, &Tp, &MS);

    //Conversion des donnees initiales en SIs
    Conversion(&rpg, &Mp, &rph, &Tp, &MS);

    //Initialisation des tableaux contenant les trajectoires du maitre et du chien
    float *Xs=NULL;
    Xs=malloc((Nt+5000)* sizeof(float));
    float *Ys=NULL;
    Ys=malloc((Nt+5000)* sizeof(float));
    float *A=NULL;
    A=malloc((Nt+5000)* sizeof(float));
    float *E=NULL;
    E=malloc((Nt+1)* sizeof(float));
    float *thetaB=NULL;
    thetaB=malloc((Nt+5000)* sizeof(float));
    float *r=NULL;
    r=malloc((Nt+5000)* sizeof(float));
    float *t=NULL;
    t=malloc((Nt+5000)* sizeof(float));
    float *Xp=NULL;
    Xp=malloc((Nt+5000)* sizeof(float));
    float *Yp=NULL;
    Yp=malloc((Nt+5000)* sizeof(float));
    float *Ap=NULL;
    Ap=malloc((Nt+5000)* sizeof(float));
    float *Ep=NULL;
    Ep=malloc((Nt+5000)* sizeof(float));
    float *thetaP=NULL;
    thetaP=malloc((Nt)* sizeof(float));
    float *rp=NULL;
    rp=malloc((Nt)* sizeof(float));
    float *F=NULL;
    F=malloc((Nt)* sizeof(float));
	float *P=NULL;
    P=malloc((Nt)* sizeof(float));

    for(int i=0;i<Nt;i++)
    {
        t[i]=i*dt;
        //printf("%f\n", t[i]); //Pour verifier que le tableau est bien construit
    }

    //Calcul de la trajectoire de la planète
    TrajectoirePlanete(&ep, &rph, &Tp, &MS, &vp, Ap, &dt, Ep, thetaP, rp, Xp, Yp, &Nt);

    //Calcul de l'excentricite du satellite en fonction de vp et rps
    ParaGravStd(&rpg, &vs, &mu, &Mp);
    SpecAngMom(&rpg, &vs, &h);
    excentricite(&h, &mu, &e, &rpg);

    printf("e = %f\n", e);

    //Calcul de la trajectoire du satellite en fonction de son excentricite
    if (e < 1)
    {
        //Trajectoire elliptique
        elliptique(&T, &mu, &h, &e, &dt, A, E, thetaB, r, Xp, Yp, Xs, Ys, &Nt);
        //Affichage de la periode de l'orbite du satellite
        T = T / 3600; //Periode en heure
        printf("Trajectoire elliptique\n");
        printf("Periode satellite = %f heures\n", T);
    }
    else if (e == 1)
    {
        //Trajectoire parabolique
        parabolique(A, &mu, &dt, &h, thetaB, r, Ys, Xs, Yp, Xp, &Nt);
        printf("Trajectoire parabolique\n");
    }
    else
    {
        //Trajectoire hyperbolique
        hyperbolique(A, &dt, &mu, &e, &h, thetaB, &F, r, Ys, Xs, Yp, Xp, &Nt,&P);
        printf("Trajectoire hyperbolique\n");
    }

    //Affichage de la position du satellite
    //AfficheTrajectoireSatellite(Xs, Ys, &Nt, t);

    //Ecriture sur le disque de la position du satellite
    EcritureTrajSatellite(Xs, Ys, &Nt);

    //Tracee du cercle representant le Soleil

    //Ecriture sur le disque de la position de la planète
    EcritureTrajPlanete(Xp, Yp, &Nt);

    //Fin du programme
    FinProg();
    return 0;
}
