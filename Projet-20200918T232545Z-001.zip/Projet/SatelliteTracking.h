//float TrajectoirePlanete(double *ep, double *rph, double *Tp, double *MS, double *vp, double *Ap, double *dt, double *Ep, double *thetaP, double *rp, double *Xp, double *Yp, int *Nt);
float ParaGravStd(double *rpg, double *vs, double *mu, double *Mp);
float SpecAngMom(double *rpg, double *vs, double *h);
float excentricite(double *h, double *mu, double *e, double *rpg);
float elliptique(double *T, double *mu, double *h, double *e, double *dt, double *A, double *E, double *thetaB, double *r, double *Xp, double *Yp, double *Xs, double *Ys, int *Nt);
float parabolique(double *A, double *mu, double *dt, double *h, double *thetaB, double *r, double *Ys, double *Xs, double *Yp, double *Xp, int *Nt);
float hyperbolique(double *A, double *dt, double *mu, double *e, double *h, double *thetaB, double *F, double *r, double *Ys, double *Xs, double *Yp, double *Xp, int *Nt);