#include <stdio.h>

int AffichageIni()
{
    printf("SATELLITE TRACKING\n");
    printf("Last modifications : 07/11/19\n");
    return 1;
}

int FinProg()
{
    printf("A bientot\n");
}

int AffichageData(double *vs, double *rpg, double *Mp, int *Nt, double *dt, double *ep, double *rph, double *Tp, double *MS)
{
    printf("vp = %.2lf m/s\n", *vs);
    printf("rp = %.2lf km\n", *rpg);
    printf("Mp = %.2lf x10^24kg\n", *Mp);
    printf("Nt = %d\n", *Nt);
    printf("dt = %.2lf secondes\n", *dt);
    printf("ep = %lf\n", *ep);
    printf("rph = %.2lf x10^9km\n", *rph);
    printf("Tp = %.2lf jours\n", *Tp);
    printf("MS = %.3lf x10^30kg\n", *MS);
}

/*int AfficheTrajectoireSatellite(double *Xs, double *Ys, int *Nt, double *t)
{
    int i;

    for (i=0;i<*Nt;i++)
    {
        printf("Xs = %.2lf\tYs = %.2lf\n", Xs[i], Ys[i]);
    }
}*/