int AffichageIni();
int FinProg();
int AffichageData(double *vs, double *rpg, double *Mp, int *Nt, double *dt, double *ep, double *rph, double *Tp, double *MS);
//int AfficheTrajectoireSatellite(double *Xs, double *Ys, int *Nt, double *t);