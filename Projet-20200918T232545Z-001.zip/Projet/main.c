#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include "SatelliteTracking.h"
#include "DiskFcts.h"
#include "ScreenFcts.h"

int main(int argc, char *argv[])
{
    //Definition des variables
    double vs = 0;
    double vp = 0;
    double poubelle = 0;
    double rpg = 0;
    double rph = 0;
    double Mp = 0;
    double MS = 0;
    double dt = 0;
    double T = 0;
    double Tp = 0;
    double mu = 0;
    double h = 0;
    double e = 0;
    double ep = 0;
    int Nt = 0;

    //Appel de la fonction gérant l'affichage de bienvenue
    AffichageIni();

    //Appel de la fonction lisant le fichier de donnees
    //Lecture du fichier de donnees (par defaut "donneesinitiales.txt")
    LectureData(&poubelle, &vs, &rpg, &Mp, &Nt, &dt, &ep, &rph, &Tp, &MS);

    //Affichage des differentes informations
    AffichageData(&vs, &rpg, &Mp, &Nt, &dt, &ep, &rph, &Tp, &MS);

    //Conversion des donnees initiales en SI
    Conversion(&rpg, &Mp, &rph, &Tp, &MS);

    //Initialisation des tableaux contenant les trajectoires du maitre et du chien
    double *Xs=NULL;
    Xs=malloc(Nt* sizeof(double));
    double *Ys=NULL;
    Ys=malloc(Nt* sizeof(double));
    double *A=NULL;
    A=malloc(Nt* sizeof(double));
    double *E=NULL;
    E=malloc(Nt* sizeof(double));
    double *thetaB=NULL;
    thetaB=malloc(Nt* sizeof(double));
    double *r=NULL;
    r=malloc(Nt* sizeof(double));
    double *t=NULL;
    t=malloc(Nt* sizeof(double));
    double *Xp=NULL;
    Xp=malloc(Nt* sizeof(double));
    double *Yp=NULL;
    Yp=malloc(Nt* sizeof(double));
    double *Ap=NULL;
    Ap=malloc(Nt* sizeof(double));
    double *Ep=NULL;
    Ep=malloc(Nt* sizeof(double));
    double *thetaP=NULL;
    thetaP=malloc(Nt* sizeof(double));
    double *rp=NULL;
    rp=malloc(Nt* sizeof(double));
    double *F=NULL;
    F=malloc(Nt* sizeof(double));

    for(int i=0;i<Nt;i++)
    {
        t[i]=i*dt;
        //printf("%f\n", t[i]); //Pour verifier que le tableau est bien construit
    }

    //Calcul de la trajectoire de la planète
    //TrajectoirePlanete(&ep, &rph, &Tp, &MS, &vp, Ap, &dt, Ep, thetaP, rp, Xp, Yp, &Nt);

    //Calcul de l'excentricite du satellite en fonction de vp et rp
    ParaGravStd(&rpg, &vs, &mu, &Mp);
    SpecAngMom(&rpg, &vs, &h);
    excentricite(&h, &mu, &e, &rpg);

    printf("e = %lf\n", e);

    //Calcul de la trajectoire du satellite en fonction de son excentricite
    if (e < 1)
    {
        //Trajectoire elliptique
        elliptique(&T, &mu, &h, &e, &dt, A, E, thetaB, r, Xp, Yp, Xs, Ys, &Nt);
        //Affichage de la periode de l'orbite du satellite
        T = T / 3600; //Periode en heure
        printf("Trajectoire elliptique\n");
        printf("Periode satellite = %f heures\n", T);
    }
    else if (e == 1)
    {
        //Trajectoire parabolique
        parabolique(A, &mu, &dt, &h, thetaB, r, Ys, Xs, Yp, Xp, &Nt);
        printf("Trajectoire parabolique\n");
    }
    else
    {
        //Trajectoire hyperbolique
        hyperbolique(A, &dt, &mu, &e, &h, thetaB, F, r, Ys, Xs, Yp, Xp, &Nt);
        printf("Trajectoire hyperbolique\n");
    }

    //Affichage de la position du satellite
    //AfficheTrajectoireSatellite(Xs, Ys, &Nt, t);

    //Ecriture sur le disque de la position du satellite
    EcritureTrajSatellite(Xs, Ys, &Nt);

    //Tracee du cercle representant le Soleil

    //Ecriture sur le disque de la position de la planète
    //EcritureTrajPlanete(Xp, Yp, &Nt);

    //Fin du programme
    FinProg();
    return 0;
}